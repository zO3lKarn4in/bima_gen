		<table class='table table-bordered'>
			<thead>
				<tr>
					<th>No</th>
					<th>Nama Lengkap</th>
					<th>Nama Panggilan</th>
					<th>Jenis Kelamin</th>
					<th>No. KK</th>
					<th>NIK</th>
					<th>Tanggal Lahir</th>
					<th>Kota Tempat Lahir</th>
					<th>Alamat Rumah</th>
					<th>Provinsi</th>
					<th>Kabupaten/Kotamadya</th>
					<th>Kecamatan</th>
					<th>Desa/Kelurahan</th>
					<th>Agama</th>
					<th>Kewarganegaraan</th>
					<th>Anak ke -</th>
					<th>Jumlah Saudara</th>
				</tr>
			</thead>
			<tbody>
				<?php $i=1 ?>
				<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i++); ?></td>
					<td><?php echo e($s->nama_lengkap); ?></td>
					<td><?php echo e($s->nama_panggilan); ?></td>
					<td><?php echo e($s->jenis_kelamin); ?></td>
					<td><?php echo e($s->no_kk); ?></td>
					<td><?php echo e($s->nik); ?></td>
					<td><?php echo e($s->tanggal_lahir); ?></td>
					<td><?php echo e($s->kota_kelahiran); ?></td>
					<td><?php echo e($s->alamat_rumah); ?></td>
					<td><?php echo e($s->kelurahan); ?></td>
					<td><?php echo e($s->kecamatan); ?></td>
					<td><?php echo e($s->kabupaten); ?></td>
					<td><?php echo e($s->provinsi); ?></td>
					<td><?php echo e($s->agama); ?></td>
					<td><?php echo e($s->kewarganegaraan); ?></td>
					<td><?php echo e($s->anak_ke); ?></td>
					<td><?php echo e($s->jumlah_saudara); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>